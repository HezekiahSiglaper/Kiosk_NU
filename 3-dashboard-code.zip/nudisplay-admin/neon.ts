/**
 * neon.ts — Neon services for NU Display Admin (project MKTG-DISPLAYS).
 *
 * Every Neon branch already has Postgres (the displays, display_commands
 * and display_events tables, see neon/schema.sql). On top of that:
 *
 *   - display-screenshots: the latest photo of each screen, stored as
 *     <display id>/latest.jpg. public_read, like the Supabase bucket it
 *     replaces, so the dashboard can show it with a plain URL. Only the
 *     server can write to it.
 *   - Realtime: live queries, so commands reach the screens and the
 *     dashboard updates without reloading. Only the origins below may
 *     connect.
 *   - Auth (Managed Better Auth): dashboard sign-in with an email magic
 *     link. Magic link, trusted domains and the email provider are branch
 *     settings outside this file (see README "Dashboard login").
 *
 * Apply with `neon deploy` from this folder.
 */
import { defineConfig } from '@neon/config/v1'

export default defineConfig({
  auth: true,
  buckets: {
    'display-screenshots': { access: 'public_read' },
  },
  preview: {
    realtime: {
      allowedOrigins: [
        // Dashboard
        'https://nudisplay-admin-phi.vercel.app',
        'http://localhost:5173',
        // Campus screens (their approved addresses)
        'https://display-barton-downstairs-nine.vercel.app',
        'https://display-barton-right-arrow-eta.vercel.app',
        'https://chapel-kappa.vercel.app',
        'https://6710.vercel.app',
        'https://pecota.vercel.app',
        'https://display-web-feehall.vercel.app',
        'https://display-web-hsc1.vercel.app',
        'https://display-web-hsc2.vercel.app',
        'https://nu-display.vercel.app',
        'https://nu-display-flame.vercel.app',
        // Local development of a screen (nuxt dev)
        'http://localhost:3000',
      ],
    },
  },
})
