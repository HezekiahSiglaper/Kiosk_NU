-- ============================================================================
-- 013_lock_down_public_key.sql
--
-- Replaces 012 (which was never applied and would have broken heartbeats:
-- it left out is_visible and has_focus, which every kiosk sends).
--
-- The publishable (anon) key ships inside every kiosk site, so anyone can
-- read it. After this migration that key can only:
--   - read the tables the dashboard and kiosks need,
--   - update a kiosk's own reporting columns (heartbeat, screenshot, power),
--   - mark a command as executed,
--   - append event logs.
-- It can no longer create commands (blackout, emergency, reload), change a
-- display's name, URLs or programming, or delete anything.
--
-- Commands are created only by the dashboard's /api/command route with the
-- service role key, which never reaches the browser.
--
-- Run in the Supabase SQL editor. Safe to run more than once.
-- ============================================================================

-- Admin server (service role): full access to the three tables.
grant select, insert, update, delete
  on public.displays, public.display_commands, public.display_events
  to service_role;

-- Displays ---------------------------------------------------------------
revoke insert, update, delete, truncate, trigger, references
  on public.displays from anon, authenticated;
grant select on public.displays to anon;
grant update (
  status,
  current_page,
  current_url,
  last_seen,
  last_touch,
  response_time,
  software_version,
  screenshot_url,
  screenshot_updated_at,
  security_status,
  security_message,
  is_secure,
  is_visible,
  has_focus,
  power_state,
  power_changed_at,
  updated_at
) on public.displays to anon;

-- Commands: kiosks read the queue and mark a command done. Nothing else.
revoke insert, update, delete, truncate, trigger, references
  on public.display_commands from anon, authenticated;
grant select on public.display_commands to anon;
grant update (executed_at) on public.display_commands to anon;

-- Events: append-only logs.
revoke update, delete, truncate, trigger, references
  on public.display_events from anon, authenticated;
grant select, insert on public.display_events to anon;
