-- ============================================================================
-- 015_kiosk_id.sql
--
-- Tells the physical campus screen apart from a test tab with a kiosk ID.
--
-- Each physical screen opens its approved address with ?kiosk=<id>, for
-- example https://display-barton-downstairs-nine.vercel.app/?kiosk=1.
-- The display app remembers that ID and sends it, together with the page's
-- origin, on every heartbeat.
--
--   kiosk_id         the ID this display's physical screen must send.
--                    Set by an admin. Empty (null) = not enforced yet: the
--                    dashboard keeps the old address-only check.
--   last_kiosk_id    the ID sent by the last heartbeat (null = none sent).
--   last_origin      the origin (https://host) of the last heartbeat.
--
-- The public (anon) key may write only last_kiosk_id and last_origin, never
-- kiosk_id, so a browser tab cannot change what counts as the real screen.
--
-- Run in the Supabase SQL editor BEFORE deploying the display apps.
-- Safe to run more than once.
-- ============================================================================

alter table public.displays
  add column if not exists kiosk_id      text,
  add column if not exists last_kiosk_id text,
  add column if not exists last_origin   text;

grant update (last_kiosk_id, last_origin) on public.displays to anon;

-- ----------------------------------------------------------------------------
-- Turn the check on for a screen ONLY after its physical kiosk has been
-- switched to the address ending in ?kiosk=1. Until then, leave kiosk_id
-- empty or that screen will show as a test tab.
--
-- update public.displays set kiosk_id = '1' where id = 'barton-downstairs';
-- update public.displays set kiosk_id = '1' where id = 'barton-right-arrow';
-- update public.displays set kiosk_id = '1' where id = 'chapel-display';
-- update public.displays set kiosk_id = '1' where id = 'nu-display';
-- update public.displays set kiosk_id = '1' where id = 'pecota';
-- update public.displays set kiosk_id = '1' where id = '6710';
-- update public.displays set kiosk_id = '1' where id = 'feehall';
-- update public.displays set kiosk_id = '1' where id = 'hsc1';
-- update public.displays set kiosk_id = '1' where id = 'hsc2';
--
-- To turn the check off again for a screen:
-- update public.displays set kiosk_id = null where id = 'barton-downstairs';
-- ----------------------------------------------------------------------------
