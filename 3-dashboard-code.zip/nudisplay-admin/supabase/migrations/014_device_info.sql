-- ============================================================================
-- 014_device_info.sql
--
-- Each kiosk reports what device it is running on (screen size, touch,
-- orientation, browser, OS) so the dashboard can tell a campus screen
-- apart from a laptop tab that happens to have the same site open.
--
-- Run in the Supabase SQL editor. Safe to run more than once, before or
-- after 013.
-- ============================================================================

alter table public.displays
  add column if not exists device_info jsonb;

grant update (device_info) on public.displays to anon;
