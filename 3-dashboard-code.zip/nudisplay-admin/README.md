# NU Display Admin

A real-time operations center for Northwest University campus digital
signage. This dashboard monitors every display registered in Supabase,
lets administrators add/edit/remove displays, and queues remote commands
(reload, go_home, blackout, emergency_message) that Phase 3 display
clients will execute via Supabase Realtime.

## Stack

- **Vite 5** + **React 18** + **TypeScript** (strict)
- **Tailwind 3** with custom Northwest University color tokens
- **Supabase** (`@supabase/supabase-js`) + **Realtime** subscriptions
- **React Router 6** (single route: `/admin/displays`)
- Zero external SaaS dependencies — pure Northwest design system

## Run locally

```bash
npm install
npm run dev          # http://localhost:5173/admin/displays
npm run build        # outputs to dist/
```

If `VITE_SUPABASE_URL` / `VITE_SUPABASE_ANON_KEY` are missing, the
dashboard falls back to **Local mode** (HEAD-probe only, no persistence)
and a "Local mode" pill appears in the header.

## Configure Supabase (Phase 2)

1. Create a Supabase project.
2. Copy `.env.example` to `.env` and fill in:
   ```
   VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJ...
   ```
3. Run the SQL migrations in order from `supabase/migrations/`:
   - `001_init.sql`     — schema (displays, display_commands, display_events), RLS, Realtime
   - `002_seed.sql`     — the four known displays as initial rows (includes `approved_url`)
   - `003_grants_policies.sql` — **required** if you see `42501 permission denied`;
     this adds explicit `GRANT SELECT … TO anon` on each table (RLS policies
     alone are not enough on Supabase)
   - `004_security.sql` — Phase 4.5: adds `approved_url`, `is_secure`,
     `security_status`, `security_message` columns to `displays` (idempotent)
4. Reload the dashboard — the five displays will appear via Realtime
   within a second or two.

## Neon

The screens and the dashboard run on Neon (since 2026-11-04). Supabase is
kept as a way back: set `VITE_DISPLAY_BACKEND=supabase` on a project in
Vercel and redeploy it.

| | |
|---|---|
| Neon project | `MKTG-DISPLAYS` (`cool-lab-46640754`), org "Northwest University", `aws-us-east-2`, Postgres 18. Data copied from Supabase on 2026-11-03. (The earlier test project `floral-bird-57238106` in the "Student Worker" org can be deleted after the switch.) |
| Branch | `production` |
| Services | Postgres, Object Storage (bucket `display-screenshots`, public read), Realtime |
| Config | [`neon.ts`](neon.ts): bucket and Realtime allowed origins |
| Tables | [`neon/schema.sql`](neon/schema.sql): same shape as Supabase after migrations 001–015 |

Set up a fresh checkout (needs Node 22.20+ for the Neon CLI):

```bash
npx neon@latest login
npx neon@latest link --project-id cool-lab-46640754 --branch production --org-id org-nameless-pond-97318895
npx neon@latest deploy          # bucket + Realtime, writes Neon vars into .env
psql "$DATABASE_URL_UNPOOLED" -f neon/schema.sql   # safe to re-run
node neon/copy-from-supabase.mjs                   # copy the data (safe to re-run)
```

The campus network blocks Postgres port 5432. From campus, run SQL with
the Neon serverless driver (WebSocket on port 443) instead of `psql`.

### Switching a screen to Neon

The screens never talk to Neon directly. They call this site's
`/api/kiosk/*` routes, and get commands from a Neon live query sealed by
`/api/kiosk/live` (it lasts one minute; the screen renews it every ~30 s).
Each display app has the switch in `lib/displayBackend.ts`:

| Vercel env var (display project) | |
|---|---|
| `VITE_DISPLAY_BACKEND` | Unset (default): Neon. `supabase`: back to Supabase, as before the move. |
| `VITE_DISPLAY_API_URL` | This site's address. Default `https://nudisplay-admin-phi.vercel.app`. |

This site needs the Neon env vars from `.env` (`DATABASE_URL`,
`NEON_REALTIME_*`, `AWS_*`) in Vercel first. Each display's `vercel.json`
CSP already allows `https://nudisplay-admin-phi.vercel.app` and
`wss://*.neon.tech` in `connect-src`; if `VITE_DISPLAY_API_URL` ever
changes, update the CSP too.

### Switching the dashboard to Neon

Same switch, in this site's Vercel env vars (`src/services/backend.ts`).
Unset: Neon and the magic-link sign-in. `VITE_DISPLAY_BACKEND=supabase`:
Supabase and Basic Auth, as before.

- **Displays (heartbeats):** read from Postgres every 15 s
  (`/api/admin/displays`), and right after each command. Heartbeats change
  these rows constantly, so a plain read costs less than Realtime.
- **Commands, events, security events:** Neon live queries sealed by
  `/api/admin/live` (commands must show "Done" at once).
- **Commands:** `/api/admin/command`.

### Dashboard login (Neon mode)

Basic Auth is off in Neon mode; people sign in with **Neon Auth (Managed
Better Auth) using an email magic link** (`src/services/auth.ts`,
`src/components/AuthGate.tsx`). A first sign-in creates the account.
Every `/api/admin/*` call carries a 15-minute JWT that
`api/_lib/adminAuth.js` checks: issued by our Neon Auth, email verified,
and the email allowed. `api/command.js` (Supabase) answers 410.

| Env var (this site) | |
|---|---|
| `VITE_NEON_AUTH_URL` | The branch Auth URL, same value as `NEON_AUTH_BASE_URL`. |
| `ADMIN_EMAILS` | Addresses allowed in, comma-separated. **Empty by default: nobody gets in until listed.** |
| `ADMIN_EMAIL_DOMAINS` | Whole domains allowed in, comma-separated. Empty by default; students can have university addresses too, so prefer `ADMIN_EMAILS`. |

`/api/admin/*` also only accepts `application/json` from the dashboard's
own page (`Sec-Fetch-Site: same-origin`), so another site can't use a
signed-in browser to send commands.

Branch settings (Neon Console → Auth, or CLI/API), as set on the test
project: Magic Link **on** (link valid 5 min, sign-up allowed), email &
password **off**, no social providers, trusted domain
`https://nudisplay-admin-phi.vercel.app` (localhost is allowed by default).
**Production needs a custom email provider (SMTP):** Neon's shared sender
is for development only.

### Switch-over checklist

1. ✅ (2026-11-03) Create the project in the Northwest University org and
   run `neon/schema.sql` there; `neon deploy` with `neon.ts`.
2. Auth on the new branch: ✅ Magic Link on, email & password and social
   providers off, trusted domain added. Still to do: the custom SMTP
   (see "Dashboard login").
3. Put the Neon env vars on this site in Vercel (server-only, never
   `VITE_`), plus `VITE_NEON_AUTH_URL` and `ADMIN_EMAILS` (required, or
   nobody can sign in). Deploy, and check a POST to
   `/api/kiosk/live` no longer answers 503 `Neon not configured`.
4. Copy the data: `node neon/copy-from-supabase.mjs` (safe to re-run).
5. Set `VITE_DISPLAY_BACKEND=neon` on this site and on each display
   project, and redeploy. Sign in with a magic link. Screens pick up the
   new build by themselves within a few minutes (auto-update).
6. Run the copy once more for events written during the switch. Keep
   Supabase read-only for a while before removing it.

## Architecture

```
src/
  services/
    supabase.ts         — singleton client (null if env missing)
    displays.ts         — CRUD: fetchDisplays, createDisplay, updateDisplay, deleteDisplay
    commands.ts         — fetchRecentCommands, sendCommand
    events.ts           — fetchRecentEvents, logEvent
  hooks/
    useDisplayStatus.ts      — single source of truth (Realtime + local probe fallback)
    useDisplayCommands.ts    — Realtime INSERT subscription on display_commands
    useDisplayEvents.ts      — Realtime INSERT subscription on display_events
    useDisplayHeartbeat.ts   — alias for useDisplayStatus (legacy name)
  components/
    Shell.tsx                 — header / nav / footer
    DisplayCard.tsx           — single display card (screenshot, page, location, times, commands)
    DisplayFormModal.tsx      — Add / Edit display
    Modal.tsx                 — generic centered glassmorphism modal
    StatusBadge.tsx           — online / offline pill
    Button.tsx                — 4 variants × 2 sizes
    NuMark.tsx                — gold NU monogram for the header
    icons.tsx                 — inline SVG icon set
  pages/
    DisplaysPage.tsx          — the only page
  types/                       — Display, Command, Event
```

### Realtime model

| Table             | Subscribed events                | Hook                    |
|-------------------|----------------------------------|-------------------------|
| `displays`        | INSERT, UPDATE, DELETE           | `useDisplayStatus`      |
| `display_commands`| INSERT                            | `useDisplayCommands`    |
| `display_events`  | INSERT                            | `useDisplayEvents`      |

Every consumer of display state (header, stats, banner, card grid,
events panel) reads from the same React state — no duplicate fetches
and no N+1 queries.

### Offline logic

A display is considered `offline` when `last_seen` is older than
**90 seconds** (3× the 30s heartbeat interval). Status is recomputed
locally every 10 seconds from `last_seen` so a display that stops
phoning home flips to `offline` even if its last persisted status
was `online`.

## Operations

### Add / edit / remove displays

For now, displays are managed **directly in Supabase** — either via
the Supabase dashboard's table editor, the SQL editor, or by running
additional migrations. The four known displays are seeded by
`supabase/migrations/002_seed.sql`. Adding more is as simple as:

```sql
insert into public.displays (id, name, location, orientation, public_url, notes)
values ('kiosk-5', 'Pavilion Display', 'Pavilion Hall', 'Center', 'https://...', '...');
```

The new row appears in the dashboard within a second or two via
Supabase Realtime — no code deploy needed. The architecture supports
10, 20, or more displays without changes.

> Full Add/Edit/Delete UI inside the dashboard is on the roadmap
> (Phase 2.5) but intentionally deferred — the SQL editor is
> currently the canonical management surface for the 10+ display
> roster.

### Send a command

On any display card, click one of the four command buttons:

- **Reload**          — re-fetch the current page
- **Go Home**         — navigate to `/`
- **Blackout**        — show a black screen
- **Emergency**       — display an emergency message

The command is inserted into `display_commands` and a `command_sent`
event is logged. Phase 3 display clients will subscribe to that table
and execute the command, then mark `executed_at`.

## Deploy to Vercel

```bash
vercel link
vercel env add VITE_SUPABASE_URL
vercel env add VITE_SUPABASE_ANON_KEY
vercel --prod
```

`serve.json` ships with SPA rewrite rules so React Router works
correctly under any static host.

## Phase 3 plan (next)

See `PHASE_3.md`.
