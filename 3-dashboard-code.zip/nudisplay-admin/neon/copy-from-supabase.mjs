/**
 * neon/copy-from-supabase.mjs — copies the display data from Supabase into
 * Neon, for the switch-over day. Safe to run again: rows are matched by id
 * and updated, never duplicated. Supabase is only read.
 *
 *   cd apps/nudisplay-admin
 *   node neon/copy-from-supabase.mjs
 *
 * Reads from .env: DATABASE_URL (Neon), VITE_SUPABASE_URL and a Supabase
 * key: SUPABASE_SERVICE_ROLE_KEY if set (reads every table), otherwise
 * VITE_SUPABASE_ANON_KEY (tables the public key can't read are skipped
 * with a warning). Variables already set in the shell win over .env.
 *
 * Uses the Neon serverless driver over HTTPS, so it works on the campus
 * network (which blocks Postgres port 5432).
 */
import fs from 'node:fs'
import { neon } from '@neondatabase/serverless'

const TABLES = ['displays', 'display_commands', 'display_events']
const PAGE = 1000 // Supabase returns at most 1000 rows per request

for (const line of fs.existsSync('.env') ? fs.readFileSync('.env', 'utf8').split('\n') : []) {
  const m = line.match(/^([A-Z0-9_]+)=(.*)$/)
  if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '')
}
const { DATABASE_URL, VITE_SUPABASE_URL } = process.env
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.VITE_SUPABASE_ANON_KEY
if (!DATABASE_URL || !VITE_SUPABASE_URL || !SUPABASE_KEY) {
  console.error('Missing DATABASE_URL, VITE_SUPABASE_URL or a Supabase key (see the top of this file).')
  process.exit(1)
}
const sql = neon(DATABASE_URL)

/**
 * Reads a whole Supabase table, page by page (oldest first). Ordered by
 * id too, so rows with the same created_at can't slip between pages.
 */
async function readSupabase(table) {
  const rows = []
  for (let offset = 0; ; offset += PAGE) {
    const res = await fetch(
      `${VITE_SUPABASE_URL}/rest/v1/${table}?select=*&order=created_at,id&limit=${PAGE}&offset=${offset}`,
      { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } },
    )
    if (!res.ok) throw new Error(`HTTP ${res.status} ${await res.text()}`)
    const page = await res.json()
    rows.push(...page)
    if (page.length < PAGE) return rows
  }
}

/**
 * Upserts rows into Neon, one page per query. Only columns both sides
 * have are copied; Neon-only columns keep their values or defaults.
 */
async function writeNeon(table, rows) {
  const neonColumns = new Set((await sql.query(
    `select column_name from information_schema.columns where table_schema = 'public' and table_name = $1`,
    [table],
  )).map((r) => r.column_name))
  const columns = [...new Set(rows.flatMap(Object.keys))].filter((c) => neonColumns.has(c))
  const skipped = [...new Set(rows.flatMap(Object.keys))].filter((c) => !neonColumns.has(c))
  if (skipped.length) console.log(`  ${table}: columns not in Neon, not copied: ${skipped.join(', ')}`)
  const list = columns.join(', ')
  const updates = columns.filter((c) => c !== 'id').map((c) => `${c} = excluded.${c}`).join(', ')
  for (let i = 0; i < rows.length; i += PAGE) {
    // Table and column names come from information_schema; the data is one JSON parameter.
    await sql.query(
      `insert into public.${table} (${list})
       select ${list} from jsonb_populate_recordset(null::public.${table}, $1::jsonb)
       on conflict (id) do update set ${updates}`,
      [JSON.stringify(rows.slice(i, i + PAGE))],
    )
  }
}

for (const table of TABLES) {
  let rows
  try {
    rows = await readSupabase(table)
  } catch (err) {
    console.warn(`⚠️  ${table}: could not read from Supabase (${err.message.slice(0, 120)}), skipped`)
    continue
  }
  if (rows.length) await writeNeon(table, rows)
  const [{ n }] = await sql.query(`select count(*)::int as n from public.${table}`)
  console.log(`✅ ${table}: ${rows.length} rows read from Supabase, ${n} now in Neon`)
}
