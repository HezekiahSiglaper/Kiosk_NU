-- ============================================================================
-- neon/schema.sql
--
-- NU Display Admin tables on Neon (project MKTG-DISPLAYS). Same shape as the
-- Supabase database after migrations 001–015, in one file.
--
-- Left out on purpose (Supabase-only):
--   - anon grants and row level security: on Neon only our own API, on the
--     server, talks to the database, so browsers never get a database key.
--   - the supabase_realtime publication: Neon Realtime needs only a
--     primary key on each table.
--   - storage policies: the display-screenshots bucket is declared in
--     neon.ts.
--
-- Run with the direct (unpooled) connection:
--   psql "$DATABASE_URL_UNPOOLED" -f neon/schema.sql
-- Safe to run more than once.
-- ============================================================================

-- One row per campus screen. Written by the screens (heartbeat, device,
-- screenshot, power) and by admins (name, URLs, kiosk ID, blackout).
create table if not exists public.displays (
  id                    text primary key,
  name                  text not null,
  location              text not null,
  orientation           text,
  notes                 text,
  public_url            text not null default '',
  current_page          text,
  current_url           text,
  status                text not null default 'offline'
                          check (status in ('online', 'offline', 'checking')),
  last_seen             timestamptz,
  last_touch            timestamptz,
  response_time         integer,
  screenshot_url        text,
  screenshot_updated_at timestamptz,
  software_version      text,
  is_blackout           boolean not null default false,
  emergency_message     text,
  -- security (Supabase 004)
  approved_url          text not null default '',
  is_secure             boolean not null default true,
  security_status       text not null default 'secure'
                          check (security_status in ('secure', 'warning', 'critical')),
  security_message      text,
  is_visible            boolean,
  has_focus             boolean,
  -- power (Supabase 006)
  power_state           text check (power_state in ('on', 'off')),
  power_changed_at      timestamptz,
  -- device that sent the last report (Supabase 014)
  device_info           jsonb,
  -- kiosk ID check (Supabase 015)
  kiosk_id              text,
  last_kiosk_id         text,
  last_origin           text,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists trg_displays_touch on public.displays;
create trigger trg_displays_touch
before update on public.displays
for each row execute function public.touch_updated_at();

create index if not exists displays_status_idx on public.displays (status);
create index if not exists displays_last_seen_idx on public.displays (last_seen desc);
create index if not exists displays_screenshot_updated_at_idx
  on public.displays (screenshot_updated_at desc);
create index if not exists displays_power_state_idx on public.displays (power_state);
create index if not exists displays_security_status_idx
  on public.displays (security_status) where security_status <> 'secure';

-- Commands from the dashboard to a screen (reload, blackout, ...).
-- The screen sets executed_at once it has run the command.
create table if not exists public.display_commands (
  id           uuid primary key default gen_random_uuid(),
  display_id   text not null references public.displays(id) on delete cascade,
  command      text not null check (command in (
                 'reload', 'go_home', 'blackout', 'emergency_message',
                 'clear_blackout', 'clear_emergency', 'power_off', 'power_on'
               )),
  payload      jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now(),
  executed_at  timestamptz
);

create index if not exists display_commands_display_idx
  on public.display_commands (display_id, created_at desc);
create index if not exists display_commands_pending_idx
  on public.display_commands (display_id) where executed_at is null;

-- Append-only log (heartbeats, security warnings, power changes, ...).
create table if not exists public.display_events (
  id          uuid primary key default gen_random_uuid(),
  display_id  text references public.displays(id) on delete set null,
  event_type  text not null,
  message     text,
  created_at  timestamptz not null default now()
);

create index if not exists display_events_recent_idx
  on public.display_events (created_at desc);
create index if not exists display_events_display_idx
  on public.display_events (display_id, created_at desc);
