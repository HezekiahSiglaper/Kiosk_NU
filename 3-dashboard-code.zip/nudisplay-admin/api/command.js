import { createClient } from '@supabase/supabase-js'
import { overlayFlags } from './_lib/overlay.js'

const ALLOWED = new Set([
  'reload',
  'go_home',
  'blackout',
  'emergency_message',
  'clear_blackout',
  'clear_emergency',
  'power_off',
  'power_on',
])

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' })
    return
  }
  // Neon mode has no Basic Auth in front of this route, and commands go
  // through /api/admin/command (Neon Auth) instead.
  if (process.env.VITE_DISPLAY_BACKEND !== 'supabase') {
    res.status(410).json({ error: 'Use /api/admin/command' })
    return
  }

  const url = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL
  const key =
    process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY
  if (!url || !key) {
    res.status(503).json({ error: 'Admin write not configured' })
    return
  }

  const { display_id, command, payload } = req.body || {}
  if (!display_id || typeof display_id !== 'string' || !ALLOWED.has(command)) {
    res.status(400).json({ error: 'Invalid command' })
    return
  }

  const sb = createClient(url, key, { auth: { persistSession: false } })
  const { data, error } = await sb
    .from('display_commands')
    .insert({
      display_id,
      command,
      payload: payload && typeof payload === 'object' ? payload : {},
    })
    .select('*')
    .single()

  if (error) {
    // Log details on the server only; never echo internals to the browser.
    console.error('display_commands insert failed:', error.message)
    res.status(500).json({ error: 'Could not queue the command' })
    return
  }

  // Record blackout / emergency on the display so the card shows it.
  // Best-effort: the command is already queued either way.
  const flags = overlayFlags(command, payload)
  if (flags) {
    const { error: flagError } = await sb.from('displays').update(flags).eq('id', display_id)
    if (flagError) console.error('displays overlay flags update failed:', flagError.message)
  }
  res.status(200).json(data)
}
