/**
 * api/_lib/overlay.js — keeps the card's "Blackout active" / "Emergency
 * active" flags (displays.is_blackout, displays.emergency_message) in step
 * with the commands the dashboard sends.
 *
 * The screens keep this state in their own browser storage and never
 * write it to the database, so the server records it when it queues the
 * command. Used by api/command.js (Supabase) and api/admin (Neon).
 */

/** Columns to update on the display for a command, or null if none. */
export function overlayFlags(command, payload) {
  switch (command) {
    case 'blackout':
      // Same default as the screen: { on: false } is the only way to say off.
      return { is_blackout: payload?.on !== false }
    case 'clear_blackout':
      return { is_blackout: false }
    case 'emergency_message': {
      // The screen ignores an empty message, so an empty one shows nothing.
      const text = String(payload?.message ?? '').trim()
      return { emergency_message: text || null }
    }
    case 'clear_emergency':
      return { emergency_message: null }
    case 'go_home': // the screen's recovery command clears both overlays
      return { is_blackout: false, emergency_message: null }
    default:
      return null
  }
}
