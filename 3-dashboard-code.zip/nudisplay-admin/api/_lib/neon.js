/**
 * api/_lib/neon.js — Neon services for the API routes (server only).
 *
 * Files under api/_lib are helpers, not routes (Vercel skips names that
 * start with "_").
 *
 *   sql()       Postgres over HTTPS (port 443) with the Neon serverless
 *               driver. Works on Vercel and on the campus network, which
 *               blocks the usual Postgres port 5432.
 *   realtime    seals live queries so browsers can subscribe to them
 *               without seeing the SQL or the secret.
 *   putScreenshot()  writes a JPEG to the display-screenshots bucket.
 *
 * Env vars come from `neon deploy` / `neon env pull` (see neon.ts).
 */
import { neon } from '@neondatabase/serverless'
import { createRealtime } from '@neon/realtime/server'
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3'

/** True when the Neon env vars are present. */
export function isNeonConfigured() {
  return Boolean(process.env.DATABASE_URL && process.env.NEON_REALTIME_SECRET)
}

let _sql = null
/** Tagged SQL client. Use sql().query(text, params) for parameterized SQL. */
export function sql() {
  if (!_sql) _sql = neon(process.env.DATABASE_URL)
  return _sql
}

/** Database name from DATABASE_URL (Realtime needs it to seal queries). */
function databaseName() {
  try {
    return new URL(process.env.DATABASE_URL).pathname.slice(1) || 'neondb'
  } catch {
    return 'neondb'
  }
}

let _realtime = null
export function realtime() {
  if (!_realtime) {
    _realtime = createRealtime({
      secret: process.env.NEON_REALTIME_SECRET,
      db: databaseName(),
    })
  }
  return _realtime
}

export const SCREENSHOT_BUCKET = 'display-screenshots'

let _s3 = null
function s3() {
  // Endpoint, region and keys come from the AWS_* env vars that neon
  // deploy writes. Neon needs path-style addressing.
  if (!_s3) _s3 = new S3Client({ forcePathStyle: true })
  return _s3
}

/**
 * Saves the latest screenshot of a display and returns its public URL.
 * One key per display, overwritten each time; the ?t= on the URL makes
 * the dashboard load the new photo instead of a cached one.
 */
export async function putScreenshot(displayId, jpeg) {
  const key = `${displayId}/latest.jpg`
  await s3().send(new PutObjectCommand({
    Bucket: SCREENSHOT_BUCKET,
    Key: key,
    Body: jpeg,
    ContentType: 'image/jpeg',
    CacheControl: 'no-cache',
  }))
  const endpoint = process.env.AWS_ENDPOINT_URL_S3.replace(/\/$/, '')
  return `${endpoint}/${SCREENSHOT_BUCKET}/${key}?t=${Date.now()}`
}
