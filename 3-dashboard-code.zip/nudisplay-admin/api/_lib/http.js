/**
 * api/_lib/http.js — small request/response helpers for the API routes.
 */

/** Sends a JSON response. */
export function send(res, status, body) {
  res.statusCode = status
  res.setHeader('Content-Type', 'application/json')
  res.end(JSON.stringify(body))
}

/** Reads the raw request body as a Buffer (Vercel may already have parsed it). */
export async function readRaw(req, maxBytes) {
  if (Buffer.isBuffer(req.body)) return req.body
  const chunks = []
  let size = 0
  for await (const chunk of req) {
    size += chunk.length
    if (size > maxBytes) throw Object.assign(new Error('Body too large'), { status: 413 })
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

/**
 * Reads a JSON request body. Vercel parses application/json into an
 * object and text/plain into a string; the screens send text/plain so
 * the browser skips the CORS preflight (see displayBackend.ts).
 */
export async function readJson(req) {
  if (req.body && typeof req.body === 'object' && !Buffer.isBuffer(req.body)) return req.body
  const raw = typeof req.body === 'string' ? req.body : (await readRaw(req, 256 * 1024)).toString('utf8')
  try {
    return raw.length ? JSON.parse(raw) : {}
  } catch {
    throw Object.assign(new Error('Invalid JSON'), { status: 400 })
  }
}

/** Origin of a URL (tolerates a missing https://), or null. */
export function originOf(url) {
  if (!url) return null
  try {
    return new URL(/^https?:\/\//.test(url) ? url : `https://${url}`).origin
  } catch {
    return null
  }
}
