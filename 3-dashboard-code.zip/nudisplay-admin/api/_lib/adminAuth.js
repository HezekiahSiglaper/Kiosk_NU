/**
 * api/_lib/adminAuth.js — who may use the dashboard API in Neon mode.
 *
 * In Neon mode (the default; VITE_DISPLAY_BACKEND=supabase turns it off) the dashboard signs people in
 * with Neon Auth (Managed Better Auth, email magic link) instead of the
 * shared Basic Auth password. The browser sends a short-lived JWT
 * (15 minutes) as `Authorization: Bearer ...`; this checks it was issued
 * by our Neon Auth and that the person is allowed:
 *
 *   - the email is verified (a magic-link sign-in verifies it), and
 *   - the email is on ADMIN_EMAILS, or its domain is on ADMIN_EMAIL_DOMAINS
 *     (comma-separated env vars). Both are empty by default: nobody gets in
 *     until someone is listed. A whole domain is opt-in because students
 *     can have addresses on the university domain too.
 *
 * Anyone can create an account by asking for a magic link, so this list
 * is what keeps the campus screens safe.
 */
import { createRemoteJWKSet, jwtVerify } from 'jose'

/** True when the dashboard uses Neon, and with it Neon Auth sign-in. */
export function usesNeonAuth() {
  return process.env.VITE_DISPLAY_BACKEND !== 'supabase'
}

function list(value) {
  return String(value || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean)
}

/** Whether this email may use the dashboard. */
export function isAllowedEmail(email) {
  const address = String(email || '').trim().toLowerCase()
  const at = address.lastIndexOf('@')
  if (at < 1) return false
  if (list(process.env.ADMIN_EMAILS).includes(address)) return true
  return list(process.env.ADMIN_EMAIL_DOMAINS).includes(address.slice(at + 1))
}

let _jwks = null
function jwks() {
  _jwks ??= createRemoteJWKSet(new URL(process.env.NEON_AUTH_JWKS_URL
    || `${process.env.NEON_AUTH_BASE_URL}/.well-known/jwks.json`))
  return _jwks
}

const fail = (status, message) => Object.assign(new Error(message), { status })

/**
 * Checks the request's sign-in. Returns the signed-in email, or throws an
 * error with status 401 (not signed in / expired) or 403 (not allowed).
 */
export async function requireAdmin(req) {
  if (!process.env.NEON_AUTH_BASE_URL) throw fail(503, 'Neon Auth not configured')
  const match = /^Bearer (.+)$/.exec(req.headers.authorization || '')
  if (!match) throw fail(401, 'Sign in required')
  let claims
  try {
    // Issued by our Neon Auth: issuer and audience are its origin.
    const origin = new URL(process.env.NEON_AUTH_BASE_URL).origin
    ;({ payload: claims } = await jwtVerify(match[1], jwks(), {
      issuer: origin,
      audience: origin,
      algorithms: ['EdDSA'],
    }))
  } catch {
    throw fail(401, 'Sign in required')
  }
  if (claims.banned) throw fail(403, 'This account is blocked')
  if (claims.emailVerified !== true) throw fail(403, 'Email not verified')
  if (!isAllowedEmail(claims.email)) throw fail(403, 'This email is not allowed to use the dashboard')
  return claims.email
}
