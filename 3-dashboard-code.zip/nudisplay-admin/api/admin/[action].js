/**
 * api/admin/[action].js — dashboard routes on Neon. Protected by the
 * dashboard's sign-in: in Neon mode a Neon Auth JWT (api/_lib/adminAuth.js),
 * otherwise the site's Basic Auth (middleware.ts).
 *
 *   POST /api/admin/displays                    all displays, read from Postgres
 *   POST /api/admin/live     { name, limit? }   sealed live query:
 *                            commands | events | security_events
 *   POST /api/admin/command  { display_id, command, payload }
 *   POST /api/admin/report   { display_id, fields }   local probe / dev tools
 *   POST /api/admin/event    { display_id, event_type, message }
 *
 * Writes return the transaction id (txid) so the dashboard can wait for
 * its own change to arrive through Realtime.
 */
import { rawSql } from '@neon/realtime/server'
import { sql, realtime, isNeonConfigured } from '../_lib/neon.js'
import { send, readJson } from '../_lib/http.js'
import { overlayFlags } from '../_lib/overlay.js'
import { usesNeonAuth, requireAdmin } from '../_lib/adminAuth.js'

/**
 * The dashboard's live queries: the same rows the Supabase version reads.
 * `limit` is how many rows a list shows (the hooks pass 30–60).
 */
const LIVE_QUERIES = {
  commands: (limit) => rawSql('SELECT * FROM display_commands ORDER BY created_at DESC LIMIT $1', [limit]),
  events: (limit) => rawSql('SELECT * FROM display_events ORDER BY created_at DESC LIMIT $1', [limit]),
  // Same types as useSecurityEvents' SECURITY_EVENT_TYPES.
  security_events: (limit) => rawSql(
    `SELECT * FROM display_events
     WHERE event_type IN ('security_warning', 'security_critical', 'kiosk_escape_detected',
                          'focus_lost', 'auto_recovery_triggered')
     ORDER BY created_at DESC LIMIT $1`,
    [limit],
  ),
}
const MAX_LIVE_ROWS = 200

const COMMANDS = new Set([
  'reload', 'go_home', 'blackout', 'emergency_message',
  'clear_blackout', 'clear_emergency', 'power_off', 'power_on',
])

/** Columns the dashboard may change on a display (everything but keys and timestamps). */
const ADMIN_COLUMNS = new Set([
  'name', 'location', 'orientation', 'notes', 'public_url', 'approved_url', 'kiosk_id',
  'status', 'current_page', 'current_url', 'last_seen', 'last_touch', 'response_time',
  'software_version', 'is_blackout', 'emergency_message', 'is_secure',
  'security_status', 'security_message', 'power_state', 'power_changed_at',
])

const TXID = 'pg_current_xact_id()::text as txid'

/**
 * The displays list, read straight from Postgres. In Neon mode the
 * dashboard polls this instead of a live query: heartbeats change the
 * rows every few seconds, and a plain read every 15 s costs less than
 * keeping a Realtime subscription busy with them.
 */
async function displays(req, res) {
  const rows = await sql().query('SELECT * FROM displays ORDER BY name')
  send(res, 200, { rows })
}

async function live(req, res) {
  const { name, limit } = await readJson(req)
  const make = LIVE_QUERIES[name]
  if (!make) return send(res, 400, { error: 'Unknown live query' })
  const rows = Math.min(MAX_LIVE_ROWS, Math.max(1, Number.parseInt(limit, 10) || 50))
  const sealed = await realtime().seal({ query: make(rows) })
  // A sealed query lasts one minute; `now` lets the browser time the
  // renewal without trusting its own clock.
  send(res, 200, { sealed, url: process.env.NEON_REALTIME_URL, now: Date.now() })
}

async function command(req, res) {
  const { display_id, command, payload } = await readJson(req)
  if (typeof display_id !== 'string' || !COMMANDS.has(command)) {
    return send(res, 400, { error: 'Invalid command' })
  }
  const rows = await sql().query(
    `insert into display_commands (display_id, command, payload)
     values ($1, $2, $3::jsonb) returning *, ${TXID}`,
    [display_id, command, JSON.stringify(payload && typeof payload === 'object' ? payload : {})],
  )
  // Record blackout / emergency on the display so the card shows it.
  // Best-effort: the command is already queued, so a failure here must not
  // report "not sent" (the admin would send it twice).
  const flags = overlayFlags(command, payload)
  if (flags) {
    const cols = Object.keys(flags) // fixed names from overlayFlags
    await sql().query(
      `update displays set ${cols.map((c, i) => `${c} = $${i + 2}`).join(', ')} where id = $1`,
      [display_id, ...Object.values(flags)],
    ).catch((err) => console.error('displays overlay flags update failed:', err.message))
  }
  send(res, 200, rows[0])
}

async function report(req, res) {
  const { display_id, fields } = await readJson(req)
  const entries = Object.entries(fields || {}).filter(([k]) => ADMIN_COLUMNS.has(k))
  if (typeof display_id !== 'string' || !entries.length) {
    return send(res, 400, { error: 'Nothing to update' })
  }
  const sets = entries.map(([k], i) => `${k} = $${i + 2}`)
  const rows = await sql().query(
    `update displays set ${sets.join(', ')} where id = $1 returning ${TXID}`,
    [display_id, ...entries.map(([, v]) => v)],
  )
  send(res, 200, { ok: true, txid: rows[0]?.txid ?? null })
}

async function event(req, res) {
  const { display_id, event_type, message } = await readJson(req)
  if (typeof event_type !== 'string' || !/^[a-z0-9_]{1,64}$/.test(event_type)) {
    return send(res, 400, { error: 'Invalid event_type' })
  }
  const rows = await sql().query(
    `insert into display_events (display_id, event_type, message)
     values ($1, $2, $3) returning ${TXID}`,
    [display_id ?? null, event_type, typeof message === 'string' ? message.slice(0, 2000) : null],
  )
  send(res, 200, { ok: true, txid: rows[0].txid })
}

/** Neon mode: confirms the sign-in is accepted (the dashboard's AuthGate). */
async function whoami(req, res, email) {
  send(res, 200, { email })
}

const ACTIONS = { whoami, displays, live, command, report, event }

/**
 * Only the dashboard's own page may call these routes. A JSON body can't
 * be sent from another site without a CORS preflight (which we never
 * answer), and the browser marks cross-site requests in Sec-Fetch-Site.
 * This stops a hostile page from using a signed-in admin's browser
 * (cached Basic Auth) to send commands.
 */
function isSameSiteJson(req) {
  const type = String(req.headers['content-type'] || '').toLowerCase()
  const site = req.headers['sec-fetch-site']
  return type.startsWith('application/json') && (!site || site === 'same-origin')
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' })
  if (!isSameSiteJson(req)) return send(res, 403, { error: 'Forbidden' })
  if (!isNeonConfigured()) return send(res, 503, { error: 'Neon not configured' })
  const action = ACTIONS[req.query?.action]
  if (!action) return send(res, 404, { error: 'Unknown action' })
  try {
    // Neon mode: Neon Auth sign-in (Basic Auth is off, see middleware.ts).
    const email = usesNeonAuth() ? await requireAdmin(req) : null
    await action(req, res, email)
  } catch (err) {
    const status = err.status || 500
    if (status === 500) console.error('admin api error:', err.message)
    send(res, status, { error: status === 500 ? 'Server error' : err.message })
  }
}
