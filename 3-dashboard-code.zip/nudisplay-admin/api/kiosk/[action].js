/**
 * api/kiosk/[action].js — what the campus screens call (replaces their
 * direct Supabase access). No login: like the old public Supabase key,
 * anyone can call it, so it only allows what a screen needs:
 *
 *   POST /api/kiosk/report       { display_id, fields }  heartbeat, device, power
 *   POST /api/kiosk/event        { display_id, event_type, message }
 *   POST /api/kiosk/command-done { display_id, command_id }
 *   POST /api/kiosk/screenshot?display_id=...   (body: image/jpeg)
 *   POST /api/kiosk/live         { display_id, since? }  sealed live query of new commands
 *
 * Every call must come from the display's approved address: the browser
 * sets the Origin header and pages can't change it. So a preview link or
 * another site can't write as a screen (scripts outside a browser can,
 * just as they could with the public Supabase key).
 *
 * The routes are exempt from the dashboard's Basic Auth (middleware.ts).
 */
import { rawSql, pgParam } from '@neon/realtime/server'
import { sql, realtime, putScreenshot, isNeonConfigured } from '../_lib/neon.js'
import { send, readJson, readRaw, originOf } from '../_lib/http.js'

/**
 * Columns a screen may set on its own row: the same list the public
 * Supabase key could write (migrations 013–015). last_seen and
 * updated_at are set by the server; screenshot_* by /screenshot.
 */
const REPORT_COLUMNS = new Set([
  'status', 'current_page', 'current_url', 'last_touch', 'response_time',
  'software_version', 'security_status', 'security_message', 'is_secure',
  'is_visible', 'has_focus', 'power_state', 'power_changed_at',
  'device_info', 'last_kiosk_id', 'last_origin',
])

const MAX_SCREENSHOT_BYTES = 2 * 1024 * 1024 // same limit as the Supabase bucket

/** Local screen development (nuxt dev) may call the API when this is on. */
const ALLOW_LOCALHOST = process.env.KIOSK_ALLOW_LOCALHOST === '1'

function setCors(req, res) {
  const origin = req.headers.origin
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin)
    res.setHeader('Vary', 'Origin')
  }
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  res.setHeader('Access-Control-Max-Age', '86400')
}

/**
 * Loads the display and checks the request comes from its approved
 * address. Throws an error with a status code otherwise.
 */
async function requireDisplay(req, displayId) {
  if (typeof displayId !== 'string' || !/^[a-z0-9-]{1,64}$/.test(displayId)) {
    throw Object.assign(new Error('Invalid display_id'), { status: 400 })
  }
  const rows = await sql().query(
    'select id, approved_url, public_url from displays where id = $1',
    [displayId],
  )
  if (!rows.length) throw Object.assign(new Error('Unknown display'), { status: 404 })
  const display = rows[0]
  const requestOrigin = originOf(req.headers.origin)
  const approved = originOf(display.approved_url || display.public_url)
  const isLocal = ALLOW_LOCALHOST && /^http:\/\/localhost(:\d+)?$/.test(requestOrigin || '')
  if (!isLocal && (!requestOrigin || requestOrigin !== approved)) {
    throw Object.assign(new Error('Not this display\'s approved address'), { status: 403 })
  }
  return display
}

async function report(req, res) {
  const { display_id, fields } = await readJson(req)
  await requireDisplay(req, display_id)
  const entries = Object.entries(fields || {}).filter(([k]) => REPORT_COLUMNS.has(k))
  if (!entries.length) return send(res, 400, { error: 'No allowed fields' })
  // Column names come from the allowlist above, values are parameters.
  const sets = entries.map(([k], i) => `${k} = $${i + 2}`)
  const values = entries.map(([k, v]) =>
    k === 'device_info' && v !== null ? JSON.stringify(v) : v)
  await sql().query(
    `update displays set ${sets.join(', ')}, last_seen = now() where id = $1`,
    [display_id, ...values],
  )
  send(res, 200, { ok: true })
}

async function event(req, res) {
  const { display_id, event_type, message } = await readJson(req)
  await requireDisplay(req, display_id)
  if (typeof event_type !== 'string' || !/^[a-z0-9_]{1,64}$/.test(event_type)) {
    return send(res, 400, { error: 'Invalid event_type' })
  }
  await sql().query(
    'insert into display_events (display_id, event_type, message) values ($1, $2, $3)',
    [display_id, event_type, typeof message === 'string' ? message.slice(0, 2000) : null],
  )
  send(res, 200, { ok: true })
}

async function commandDone(req, res) {
  const { display_id, command_id } = await readJson(req)
  await requireDisplay(req, display_id)
  // A screen can only acknowledge its own commands, once.
  const rows = await sql().query(
    `update display_commands set executed_at = now()
     where id = $1::uuid and display_id = $2 and executed_at is null
     returning id`,
    [command_id, display_id],
  )
  send(res, 200, { ok: true, updated: rows.length })
}

async function screenshot(req, res) {
  const displayId = req.query?.display_id ?? new URL(req.url, 'http://x').searchParams.get('display_id')
  await requireDisplay(req, displayId)
  const jpeg = await readRaw(req, MAX_SCREENSHOT_BYTES)
  // readRaw only counts bytes it streams itself; Vercel may hand over an
  // already-read Buffer, so check the size here too.
  if (jpeg.length > MAX_SCREENSHOT_BYTES) return send(res, 413, { error: 'Body too large' })
  // JPEG files start with FF D8 FF.
  if (jpeg.length < 3 || jpeg[0] !== 0xff || jpeg[1] !== 0xd8 || jpeg[2] !== 0xff) {
    return send(res, 400, { error: 'Not a JPEG' })
  }
  const url = await putScreenshot(displayId, jpeg)
  await sql().query(
    'update displays set screenshot_url = $2, screenshot_updated_at = now() where id = $1',
    [displayId, url],
  )
  send(res, 200, { ok: true, url })
}

/**
 * Sealed live query of this display's commands created after `since`
 * (when the screen first subscribed), so a screen that reconnects never
 * replays old commands, as with Supabase Realtime INSERT events.
 *
 * The first call leaves `since` out and the server uses its own clock, so
 * a screen whose clock is wrong still gets new commands. The response
 * returns that `since`; the screen sends it back when it renews the
 * subscription before it expires.
 */
async function live(req, res) {
  const { display_id, since } = await readJson(req)
  await requireDisplay(req, display_id)
  const sinceDate = since == null ? new Date() : new Date(since)
  if (Number.isNaN(sinceDate.getTime())) return send(res, 400, { error: 'Invalid since' })
  const query = rawSql(
    `SELECT id, display_id, command, payload, created_at, executed_at
     FROM display_commands
     WHERE display_id = $1 AND created_at > $2 AND executed_at IS NULL
     ORDER BY created_at`,
    [display_id, pgParam.timestamptz(sinceDate)],
  )
  const sealed = await realtime().seal({ query })
  // `now` lets the screen time the renewal without trusting its own clock.
  send(res, 200, {
    sealed,
    url: process.env.NEON_REALTIME_URL,
    since: sinceDate.toISOString(),
    now: Date.now(),
  })
}

const ACTIONS = { report, event, 'command-done': commandDone, screenshot, live }

export default async function handler(req, res) {
  setCors(req, res)
  if (req.method === 'OPTIONS') { res.statusCode = 204; return res.end() }
  if (req.method !== 'POST') return send(res, 405, { error: 'Method not allowed' })
  if (!isNeonConfigured()) return send(res, 503, { error: 'Neon not configured' })
  const action = ACTIONS[req.query?.action]
  if (!action) return send(res, 404, { error: 'Unknown action' })
  try {
    await action(req, res)
  } catch (err) {
    const status = err.status || 500
    if (status === 500) console.error('kiosk api error:', err.message)
    send(res, status, { error: status === 500 ? 'Server error' : err.message })
  }
}
