/**
 * Dashboard sign-in in Neon mode: Neon Auth (Managed Better Auth) with an
 * email magic link. Someone types their email, gets a link, clicks it and
 * comes back signed in. A first sign-in creates the account.
 *
 * The server decides who may use the dashboard (api/_lib/adminAuth.js:
 * verified northwestu.edu addresses by default). Every API call carries a
 * short-lived JWT from getAuthToken().
 *
 * VITE_NEON_AUTH_URL is the branch's Auth URL (NEON_AUTH_BASE_URL in
 * .env). It is public, like the Supabase URL.
 */
/** The Better Auth client (default adapter). Loaded only in Neon mode. */
async function makeClient() {
  const { createAuthClient } = await import('@neon/auth')
  return createAuthClient(import.meta.env.VITE_NEON_AUTH_URL ?? '')
}

let _client: ReturnType<typeof makeClient> | null = null
function authClient(): ReturnType<typeof makeClient> {
  _client ??= makeClient()
  return _client
}

/**
 * The magic-link method. The SDK loads the plugin at runtime
 * (supportedBetterAuthClientPlugins in @neon/auth 0.8) but its typings
 * leave it out.
 */
type PluginMethods = {
  signIn: {
    magicLink: (args: { email: string; callbackURL: string }) =>
      Promise<{ error: { message?: string } | null }>
  }
}
async function pluginMethods(): Promise<PluginMethods> {
  return (await authClient()) as unknown as PluginMethods
}

/** Email of the signed-in person, or null. */
export async function getSignedInEmail(): Promise<string | null> {
  const { data } = await (await authClient()).getSession()
  return data?.user?.email ?? null
}

/** Emails a sign-in link that brings the person back to this page. */
export async function sendMagicLink(email: string): Promise<void> {
  const { error } = await (await pluginMethods()).signIn.magicLink({
    email,
    callbackURL: window.location.href,
  })
  if (error) throw new Error(error.message || 'Could not send the sign-in link')
}

export async function signOut(): Promise<void> {
  _token = null
  await (await authClient()).signOut()
}

/* -----------------------------------------------------------------
 * JWT for the API (15-minute lifetime)
 * ----------------------------------------------------------------- */

let _token: { value: string; expiresAt: number } | null = null

/** Expiry (ms) from a JWT's `exp` claim. */
function expiryOf(jwt: string): number {
  try {
    const payload = JSON.parse(atob(jwt.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')))
    return Number(payload.exp) * 1000
  } catch {
    return 0
  }
}

/** Drops the cached JWT so the next call fetches a new one. */
export function forgetAuthToken(): void {
  _token = null
}

/** A valid JWT for the signed-in person (renewed a minute before it expires), or null. */
export async function getAuthToken(): Promise<string | null> {
  if (_token && Date.now() < _token.expiresAt - 60_000) return _token.value
  // Better Auth's JWT endpoint, read with the session cookie. (The SDK's
  // token() method didn't return it in @neon/auth 0.8.)
  const res = await fetch(`${import.meta.env.VITE_NEON_AUTH_URL}/token`, { credentials: 'include' })
  const value = res.ok ? ((await res.json()) as { token?: string }).token : undefined
  _token = value ? { value, expiresAt: expiryOf(value) } : null
  return _token?.value ?? null
}
