import { createClient, type SupabaseClient } from '@supabase/supabase-js'
import { USE_NEON } from './backend'

/**
 * Single Supabase client used everywhere in the app.
 * Returns null if the env vars are missing — in that case the dashboard
 * falls back to local URL-polling so it still runs in dev / Phase 1.
 * Also null in Neon mode (services/backend.ts).
 */
let _client: SupabaseClient | null = null

export function getSupabase(): SupabaseClient | null {
  if (USE_NEON) return null
  if (_client) return _client
  const url = import.meta.env.VITE_SUPABASE_URL
  const key = import.meta.env.VITE_SUPABASE_ANON_KEY
  if (!url || !key) return null
  _client = createClient(url, key, {
    realtime: { params: { eventsPerSecond: 5 } },
    auth: { persistSession: false },
  })
  return _client
}

/**
 * True when the dashboard has a backend to read and write: Neon mode, or
 * both Supabase env vars. The UI uses it to enable commands.
 */
export function isSupabaseConfigured(): boolean {
  if (USE_NEON) return true
  return Boolean(import.meta.env.VITE_SUPABASE_URL) &&
         Boolean(import.meta.env.VITE_SUPABASE_ANON_KEY)
}
