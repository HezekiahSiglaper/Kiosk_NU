import type { RealtimeClient, SealedLiveQuery } from '@neon/realtime/client'
import { getAuthToken } from './auth'

/**
 * The switch between Neon (default) and Supabase for the dashboard.
 *
 * In Neon mode the dashboard reads and writes through this site's
 * /api/admin/* routes, and people sign in with an email magic link (Neon
 * Auth, services/auth.ts) instead of the shared password.
 * VITE_DISPLAY_BACKEND=supabase (Vercel env var of this site) goes back to
 * Supabase and the shared password, as before the move.
 *
 * The displays list is read from Postgres every 15 s (heartbeats). The
 * command, event and security lists are Neon live queries: the browser
 * never sees the database, /api/admin/live hands it a sealed (encrypted,
 * one-minute) query, and it renews it every ~30 s.
 */
export const USE_NEON = import.meta.env.VITE_DISPLAY_BACKEND !== 'supabase'

/** Fired when the API says the sign-in is missing or expired (AuthGate shows sign-in). */
export const SIGNED_OUT_EVENT = 'nu-display:signed-out'

/**
 * POSTs JSON to /api/admin/<action> and returns the JSON reply, with the
 * signed-in person's JWT (Neon Auth, services/auth.ts).
 */
export async function adminPost<T>(action: string, body: unknown): Promise<T> {
  const token = await getAuthToken().catch(() => null)
  const res = await fetch(`/api/admin/${action}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    credentials: 'same-origin',
    body: JSON.stringify(body),
  })
  if (res.status === 401) window.dispatchEvent(new Event(SIGNED_OUT_EVENT))
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(err.error || `${action} failed`)
  }
  return (await res.json()) as T
}

/* -----------------------------------------------------------------
 * Displays list: read from Postgres every DISPLAYS_POLL_MS
 * ----------------------------------------------------------------- */

/**
 * Heartbeats change the displays every few seconds, so the list is read
 * from Postgres on a timer instead of through Realtime (cheaper; screens
 * only report every 30 s anyway). Commands and events stay live.
 */
export const DISPLAYS_POLL_MS = 15_000

/** Fired after a command, so the list (blackout / emergency flags) refreshes at once. */
const REFRESH_EVENT = 'nu-display:refresh-displays'

export function refreshDisplaysSoon(): void {
  window.dispatchEvent(new Event(REFRESH_EVENT))
}

/**
 * Keeps the displays list current. `onRows` gets the full list on start,
 * every DISPLAYS_POLL_MS and after each command. Returns a stop function.
 */
export function pollDisplays<Row>(
  onRows: (rows: Row[]) => void,
  opts: { onError?: (message: string) => void } = {},
): () => void {
  let stopped = false
  const load = async () => {
    try {
      const { rows } = await adminPost<{ rows: Row[] }>('displays', {})
      if (!stopped) onRows(rows)
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      console.warn('[displays]', message)
      if (!stopped) opts.onError?.(message)
    }
  }
  void load()
  const timer = setInterval(() => { void load() }, DISPLAYS_POLL_MS)
  const onRefresh = () => { void load() }
  window.addEventListener(REFRESH_EVENT, onRefresh)
  return () => {
    stopped = true
    clearInterval(timer)
    window.removeEventListener(REFRESH_EVENT, onRefresh)
  }
}

/* -----------------------------------------------------------------
 * Live lists
 * ----------------------------------------------------------------- */

export type LiveName = 'commands' | 'events' | 'security_events'

type LiveResponse<Row> = { sealed: SealedLiveQuery<Row>; url: string; now: number }

/** Retry delay after the API or the live connection fails. */
const RETRY_AFTER_MS = 30_000

/** Retry delay when fetching a renewal fails (the capability lasts only a minute). */
const RENEW_RETRY_MS = 5_000

/**
 * A new WebSocket client. Each list has its own, so one that gives up can
 * be replaced without touching the others. Loaded only in Neon mode, so
 * the Supabase build doesn't download it.
 */
async function newRealtimeClient(url: string): Promise<RealtimeClient> {
  const { createRealtimeClient } = await import('@neon/realtime/client')
  return createRealtimeClient({ url })
}

/**
 * Timestamps arrive as Date objects; the dashboard was written for the
 * ISO strings Supabase returns, so convert them back.
 */
function withIsoDates<Row>(row: Row): Row {
  const out: Record<string, unknown> = { ...(row as Record<string, unknown>) }
  for (const [key, value] of Object.entries(out)) {
    if (value instanceof Date) out[key] = value.toISOString()
  }
  return out as Row
}

/**
 * Keeps a list current through a Neon live query. `onRows` gets the full
 * list on start and again on every change. Returns a stop function for
 * a React effect's cleanup.
 *
 * When the live connection gives up for good (status `error`: the
 * library has stopped recovering and refuses renewals), it is closed and
 * a new one opened after RETRY_AFTER_MS.
 */
export function subscribeLive<Row>(
  name: LiveName,
  onRows: (rows: Row[]) => void,
  opts: { limit?: number; onError?: (message: string) => void } = {},
): () => void {
  let stopped = false
  let closeConnection: (() => void) | null = null

  const fail = (err: unknown) => {
    const message = err instanceof Error ? err.message : String(err)
    console.warn(`[live ${name}]`, message)
    opts.onError?.(message)
  }
  const fetchLive = () => adminPost<LiveResponse<Row>>('live', { name, limit: opts.limit })
  /** A minute before expiry, or halfway through a shorter lifetime. */
  const renewDelay = (live: LiveResponse<Row>) => {
    const lifetime = live.sealed.expiresAt - live.now // both server time
    return Math.max(10_000, lifetime - Math.min(60_000, lifetime / 2))
  }

  /** One live connection with its renewals. Resolves once it has given up or is stopped. */
  async function runConnection(first: LiveResponse<Row>): Promise<void> {
    const client = await newRealtimeClient(first.url)
    const sub = client.subscribe(first.sealed)
    let renewTimer: ReturnType<typeof setTimeout> | undefined
    let renewing = false
    return new Promise((done) => {
      let ended = false
      const end = () => {
        if (ended) return
        ended = true
        clearTimeout(renewTimer)
        try { sub.unsubscribe() } catch { /* already closed */ }
        try { client.close() } catch { /* already closed */ }
        closeConnection = null
        done()
      }
      closeConnection = end

      async function renew(): Promise<void> {
        if (renewing || ended) return
        renewing = true
        clearTimeout(renewTimer)
        try {
          const next = await fetchLive()
          if (ended) return
          // Schedule the next renewal BEFORE applying this one, and don't
          // wait for it: sub.renew() can stay pending for minutes while the
          // socket is down, and must never hold back the renewals after it.
          renewTimer = setTimeout(() => { void renew() }, renewDelay(next))
          sub.renew(next.sealed).catch((err) => {
            fail(err)
            // Not recoverable on this connection: start a new one.
            if ((err as { retryable?: boolean }).retryable === false) end()
          })
        } catch (err) {
          fail(err)
          renewTimer = setTimeout(() => { void renew() }, RENEW_RETRY_MS)
        } finally {
          renewing = false
        }
      }

      sub.onChange(({ data, status, error }) => {
        if (ended || stopped) return
        if (error) fail(error)
        if (status === 'error') return end()
        if (status === 'stale') void renew() // expired before the timer fired
        if (data) onRows((data as readonly Row[]).map(withIsoDates))
      })
      renewTimer = setTimeout(() => { void renew() }, renewDelay(first))
      if (stopped) end()
    })
  }

  void (async () => {
    while (!stopped) {
      try {
        const first = await fetchLive()
        if (stopped) return
        await runConnection(first)
      } catch (err) {
        fail(err)
      }
      if (!stopped) await new Promise((r) => setTimeout(r, RETRY_AFTER_MS))
    }
  })()

  return () => {
    stopped = true
    closeConnection?.()
  }
}
