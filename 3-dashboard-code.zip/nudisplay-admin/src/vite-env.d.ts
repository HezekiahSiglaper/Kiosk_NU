/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL?: string
  readonly VITE_SUPABASE_ANON_KEY?: string
  /** 'neon' switches the dashboard to Neon (services/backend.ts). */
  readonly VITE_DISPLAY_BACKEND?: string
  /** Neon Auth URL of the branch (= NEON_AUTH_BASE_URL), for sign-in in Neon mode. */
  readonly VITE_NEON_AUTH_URL?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
