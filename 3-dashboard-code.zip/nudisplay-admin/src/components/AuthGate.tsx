import { createContext, useCallback, useContext, useEffect, useRef, useState, type FormEvent, type ReactNode } from 'react'
import { NuMark } from './NuMark'
import { Button } from './Button'
import { USE_NEON, adminPost, SIGNED_OUT_EVENT } from '../services/backend'
import { getSignedInEmail, sendMagicLink, signOut, forgetAuthToken } from '../services/auth'

/**
 * Sign-in for the dashboard in Neon mode (services/auth.ts): email magic
 * link. Shows the sign-in card until the person is signed in AND the
 * server accepts them (api/_lib/adminAuth.js). In Supabase mode it renders
 * the dashboard straight away (the site's Basic Auth already protects it).
 */

type Session = { email: string; signOut: () => void } | null
const SessionContext = createContext<Session>(null)

/** The signed-in person (Neon mode), for the header. Null in Supabase mode. */
export function useSession(): Session {
  return useContext(SessionContext)
}

type State =
  | { step: 'checking' }
  | { step: 'sign-in'; error?: string }
  | { step: 'sending'; email: string }
  | { step: 'link-sent'; email: string }
  | { step: 'not-allowed'; email: string; reason: string }
  | { step: 'signed-in'; email: string }

export function AuthGate({ children }: { children: ReactNode }) {
  if (!USE_NEON) return <>{children}</>
  return <NeonAuthGate>{children}</NeonAuthGate>
}

function NeonAuthGate({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>({ step: 'checking' })
  const checking = useRef(false)

  /** Signed in with Neon Auth, and allowed by the server? */
  const check = useCallback(async () => {
    if (checking.current) return // a 401 during the check must not start another
    checking.current = true
    forgetAuthToken() // a fresh JWT, in case the cached one was the problem
    try {
      const email = await getSignedInEmail()
      if (!email) return setState({ step: 'sign-in' })
      try {
        await adminPost('whoami', {})
        setState({ step: 'signed-in', email })
      } catch (err) {
        const reason = err instanceof Error ? err.message : String(err)
        // 401 even with a fresh JWT: the session is gone, sign in again.
        if (reason === 'Sign in required') setState({ step: 'sign-in' })
        else setState({ step: 'not-allowed', email, reason })
      }
    } catch {
      setState({ step: 'sign-in', error: 'Could not reach the sign-in service. Try again in a minute.' })
    } finally {
      checking.current = false
    }
  }, [])

  useEffect(() => {
    void check()
    // The API answered 401: check again with a fresh JWT before asking the
    // person for a new link (the session may still be valid).
    const onSignedOut = () => { void check() }
    window.addEventListener(SIGNED_OUT_EVENT, onSignedOut)
    return () => window.removeEventListener(SIGNED_OUT_EVENT, onSignedOut)
  }, [check])

  const leave = useCallback(() => {
    void signOut().finally(() => setState({ step: 'sign-in' }))
  }, [])

  if (state.step === 'signed-in') {
    return (
      <SessionContext.Provider value={{ email: state.email, signOut: leave }}>
        {children}
      </SessionContext.Provider>
    )
  }
  return <SignInCard state={state} setState={setState} onSignOut={leave} />
}

function SignInCard({ state, setState, onSignOut }: {
  state: Exclude<State, { step: 'signed-in' }>
  setState: (s: State) => void
  onSignOut: () => void
}) {
  const [email, setEmail] = useState('')

  async function onSubmit(e: FormEvent) {
    e.preventDefault()
    const address = email.trim()
    if (!address) return
    setState({ step: 'sending', email: address })
    try {
      await sendMagicLink(address)
      setState({ step: 'link-sent', email: address })
    } catch (err) {
      setState({ step: 'sign-in', error: err instanceof Error ? err.message : 'Could not send the link' })
    }
  }

  return (
    <div className="min-h-full flex items-center justify-center px-6 py-16">
      <div className="nu-card w-full max-w-md p-8 flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <NuMark size={36} />
          <div className="leading-tight">
            <div className="font-serif text-[20px] text-nu-wisp leading-none">Northwest University</div>
            <div className="nu-eyebrow mt-1">Operations Center</div>
          </div>
        </div>

        {state.step === 'checking' && (
          <p className="text-[14px] text-nu-skylight">Checking your sign-in…</p>
        )}

        {(state.step === 'sign-in' || state.step === 'sending') && (
          <form onSubmit={onSubmit} className="flex flex-col gap-4">
            <div>
              <h1 className="text-[26px] text-nu-wisp leading-tight">Sign in</h1>
              <p className="mt-2 text-[14px] text-nu-skylight">
                Enter your Northwest University email. We'll send you a link to sign in. No password needed.
              </p>
            </div>
            <label className="flex flex-col gap-2 text-[12px] font-semibold tracking-wide text-nu-skylight">
              Email
              <input
                type="email"
                required
                autoComplete="email"
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@northwestu.edu"
                className="h-11 rounded-full bg-white/[0.06] border border-white/15 px-4 text-[14px] text-nu-wisp
                           placeholder:text-nu-skylight/60 focus:outline-none focus:border-nu-tour/60"
              />
            </label>
            <Button type="submit" variant="primary" disabled={state.step === 'sending'}>
              {state.step === 'sending' ? 'Sending…' : 'Email me a sign-in link'}
            </Button>
            {state.step === 'sign-in' && state.error && (
              <p role="alert" className="text-[13px] text-nu-amber">{state.error}</p>
            )}
          </form>
        )}

        {state.step === 'link-sent' && (
          <div className="flex flex-col gap-4">
            <h1 className="text-[26px] text-nu-wisp leading-tight">Check your email</h1>
            <p className="text-[14px] text-nu-skylight">
              We sent a sign-in link to <strong className="text-nu-wisp">{state.email}</strong>.
              Open it on this device within 5 minutes.
            </p>
            <Button variant="ghost" onClick={() => setState({ step: 'sign-in' })}>
              Use a different email
            </Button>
          </div>
        )}

        {state.step === 'not-allowed' && (
          <div className="flex flex-col gap-4">
            <h1 className="text-[26px] text-nu-wisp leading-tight">No access yet</h1>
            <p className="text-[14px] text-nu-skylight">
              <strong className="text-nu-wisp">{state.email}</strong> is signed in, but it can't use the
              Operations Center ({state.reason}). Use your Northwest University email, or ask an admin to add yours.
            </p>
            <Button variant="secondary" onClick={onSignOut}>Sign out</Button>
          </div>
        )}
      </div>
    </div>
  )
}
