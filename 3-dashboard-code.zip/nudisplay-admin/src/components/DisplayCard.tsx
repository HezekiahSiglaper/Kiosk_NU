import type { Display } from '../types/display'
import type { DisplayCommand } from '../types/command'
import { StatusBadge } from './StatusBadge'
import { SecurityBadge } from './SecurityBadge'
import { SecurityAlert } from './SecurityAlert'
import { Button } from './Button'
import { ScreenshotPanel } from './ScreenshotPanel'
import { CommandStatus } from './CommandStatus'
import {
  IconExternal, IconRefresh, IconHome, IconBlock, IconAlert,
  IconMapPin, IconDisplay, IconClock, IconBolt, IconCheck,
} from './icons'
import { sendCommand } from '../services/commands'
import { logEvent } from '../services/events'
import { isSupabaseConfigured } from '../services/supabase'
import { useState, useEffect, useRef, type ReactNode } from 'react'

type Props = {
  display: Display
  commands: DisplayCommand[]
  refreshTick?: number
}

type CommandName =
  | 'reload' | 'go_home' | 'blackout' | 'emergency_message'
  | 'clear_blackout' | 'clear_emergency'
  | 'power_off' | 'power_on'
type CommandUiState = 'idle' | 'sending' | 'queued' | 'executed' | 'error'

function timeAgo(iso: string | null): string {
  if (!iso) return '—'
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 0) return 'just now'
  if (diff < 5_000) return 'just now'
  if (diff < 60_000) return `${Math.floor(diff / 1000)}s ago`
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`
  if (diff < 172_800_000) return `${Math.floor(diff / 3_600_000)}h ago`
  return `${Math.floor(diff / 86_400_000)} days ago`
}

/**
 * True when the reporting device looks like a personal computer rather
 * than a campus screen. Campus screens are touch panels or portrait
 * (1080x1920); a laptop or desktop is landscape with no touch. A screen
 * labeled "Portrait" in the table that reports a landscape, non-touch
 * device is always treated as a computer, however large its monitor.
 */
function looksLikeComputer(d: Display['device_info'], orientation: string | null): boolean {
  if (!d) return false
  if (d.touch_points > 0) return false
  const landscape = d.screen_w > d.screen_h
  if (!landscape) return false
  if (/portrait/i.test(orientation || '')) return true
  return Math.max(d.screen_w, d.screen_h) < 1900
}

function deviceSummary(d: Display['device_info']): string {
  if (!d) return '—'
  const touch = d.touch_points > 0 ? 'touch' : 'no touch'
  return `${d.screen_w}×${d.screen_h}, ${touch}, ${d.os}, ${d.browser}`
}

/** Origin of a URL (tolerates a missing https://), or null. */
function originOf(u: string | null | undefined): string | null {
  if (!u) return null
  try {
    return new URL(/^https?:\/\//.test(u) ? u : `https://${u}`).origin
  } catch {
    return null
  }
}

/** Why the last heartbeat was not the physical screen, or null if it was. */
type TestTabReason = 'wrong_domain' | 'missing_id' | 'wrong_id'

/**
 * Decides whether the last heartbeat came from the physical screen.
 *
 * It must come from the approved address AND, once an admin has set a
 * kiosk ID for this display, carry that same ID (the screen opens its
 * address with ?kiosk=<id>). Displays without a kiosk ID set keep the
 * address-only check.
 */
function testTabReason(display: Display): TestTabReason | null {
  const officialOrigin = originOf(display.approved_url || display.public_url)
  const reportingOrigin = originOf(display.last_origin) ?? originOf(display.current_url)
  if (officialOrigin && reportingOrigin && officialOrigin !== reportingOrigin) return 'wrong_domain'
  const expectedId = display.kiosk_id?.trim()
  if (!expectedId) return null
  const sentId = display.last_kiosk_id?.trim()
  if (!sentId) return 'missing_id'
  if (sentId !== expectedId) return 'wrong_id'
  return null
}

/** Plain-language explanation shown on the card for a test-tab signal. */
function testTabMessage(display: Display, reason: TestTabReason): string {
  const host = originOf(display.last_origin) ?? originOf(display.current_url)
  const where = host ? new URL(host).host : 'another address'
  switch (reason) {
    case 'wrong_domain':
      return `The last signal came from a test tab on the wrong address (${where}), not from the screen on campus.`
    case 'missing_id':
      return `The last signal came from a test tab: it was opened without ?kiosk=${display.kiosk_id}, so it is not the screen on campus.`
    case 'wrong_id':
      return `The last signal came from a test tab: its kiosk ID is "${display.last_kiosk_id}" but this screen's ID is "${display.kiosk_id}".`
  }
}

/**
 * Whether the command buttons should be enabled.
 *
 * Phase 4 made the buttons sensitive to `display.status === 'online'`,
 * but the column can be `undefined` when the seed schema doesn't yet
 * expose `security_status` (migration 004 not run). To avoid locking
 * admins out in that window, we treat `undefined`, `'online'` and
 * `'checking'` as commandable. `'offline'` is the only blocking state.
 *
 * Offline displays block every command, Go Home included: kiosks only
 * listen for new commands while connected, so a command sent while a
 * screen is offline would sit in the queue forever.
 */
/**
 * Suggested headline for the emergency overlay; the admin can edit it.
 * The screen already adds "EMERGENCY NOTICE" above it and "Please follow
 * staff instructions." below it.
 */
const DEFAULT_EMERGENCY_MESSAGE = 'Campus alert in effect'

/** How long a button says "Done" after the screen confirms its command. */
const DONE_FLASH_MS = 4_000

function isCommandable(display: Display, supabaseReady: boolean): boolean {
  if (!supabaseReady) return false
  if (display.status === 'offline') return false
  return true
}

export function DisplayCard({ display, commands }: Props) {
  const [busyCmd, setBusyCmd] = useState<CommandName | null>(null)
  const [cmdState, setCmdState] = useState<Record<CommandName, CommandUiState>>({
    reload: 'idle',
    go_home: 'idle',
    blackout: 'idle',
    emergency_message: 'idle',
    clear_blackout: 'idle',
    clear_emergency: 'idle',
    power_off: 'idle',
    power_on: 'idle',
  })
  const [cmdError, setCmdError] = useState<string | null>(null)
  const supabaseReady = isSupabaseConfigured()
  // Wrong address, or (once a kiosk ID is set) a missing / wrong kiosk ID.
  const testReason = testTabReason(display)
  const fromTestLink = testReason !== null
  // "Live" = the real screen on its official address is reporting right now.
  // A test tab on another address never counts as the screen being online.
  const fromComputer = looksLikeComputer(display.device_info, display.orientation)
  const live = display.status === 'online' && !fromTestLink && !fromComputer
  const commandable = isCommandable(display, supabaseReady) && !fromTestLink && !fromComputer

  const blackoutActive = Boolean(display.is_blackout)
  const emergencyActive = Boolean(display.emergency_message)

  /**
   * "Done" flashes for DONE_FLASH_MS when the screen confirms a command
   * this card sent, matched by its id and timed by this browser's clock.
   * History and other displays' commands never change a button's label
   * (they used to make "Done" stick, hiding "End Blackout").
   */
  const [waitingFor, setWaitingFor] = useState<Partial<Record<CommandName, string>>>({})
  const doneTimers = useRef<ReturnType<typeof setTimeout>[]>([])
  useEffect(() => () => doneTimers.current.forEach(clearTimeout), [])

  useEffect(() => {
    const confirmed = (Object.entries(waitingFor) as [CommandName, string][])
      .filter(([, id]) => commands.some((c) => c.id === id && c.executed_at))
      .map(([cmd]) => cmd)
    if (!confirmed.length) return
    setWaitingFor((prev) => {
      const next = { ...prev }
      for (const cmd of confirmed) delete next[cmd]
      return next
    })
    setCmdState((prev) => {
      const next = { ...prev }
      for (const cmd of confirmed) next[cmd] = 'executed'
      return next
    })
    doneTimers.current.push(setTimeout(() => {
      setCmdState((prev) => {
        const next = { ...prev }
        for (const cmd of confirmed) if (next[cmd] === 'executed') next[cmd] = 'idle'
        return next
      })
    }, DONE_FLASH_MS))
  }, [commands, waitingFor])

  async function onCommand(cmd: CommandName, label: string) {
    if (!supabaseReady) {
      window.alert('Supabase not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env to enable commands.')
      return
    }
    if (busyCmd) return // already sending another command

    // The screen only shows the emergency overlay with a message, so ask
    // for one (this also serves as the confirmation).
    let commandPayload: Record<string, unknown> = {}
    if (cmd === 'emergency_message') {
      const message = window.prompt(
        `Message for the EMERGENCY overlay on “${display.name}”:`,
        DEFAULT_EMERGENCY_MESSAGE,
      )?.trim()
      if (!message) return
      commandPayload = { message }
    }

    const dangerous = cmd === 'blackout' || cmd === 'power_off'
    if (dangerous) {
      const ok = window.confirm(
        cmd === 'blackout'
          ? `Black out “${display.name}”? The TV will go dark until you clear it.`
          : `Power off “${display.name}”?`,
      )
      if (!ok) return
    }

    const payload = { displayId: display.id, command: cmd }
    if (import.meta.env.DEV) {
      // eslint-disable-next-line no-console
      console.log('[command] clicked', { ...payload, label })
    }

    setBusyCmd(cmd)
    setCmdState((s) => ({ ...s, [cmd]: 'sending' }))
    setCmdError(null)


    try {
      const inserted = await sendCommand(display.id, cmd, commandPayload)
      setWaitingFor((w) => ({ ...w, [cmd]: inserted.id }))
      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        console.log('[command] supabase insert ok', { id: inserted.id, command: cmd })
      }
      setCmdState((s) => ({ ...s, [cmd]: 'queued' }))
      await logEvent('command_sent', {
        displayId: display.id,
        message: `${label} command sent to ${display.name}`,
      })
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to send command'
      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        console.error('[command] supabase insert failed', { command: cmd, error: msg })
      }
      console.warn('[command] send failed', msg)
      const friendly = 'The command could not be sent. Please try again in a minute.'
      setCmdState((s) => ({ ...s, [cmd]: 'error' }))
      setCmdError(friendly)
      window.alert(friendly)
    } finally {
      setBusyCmd(null)
      // Reset to idle after 4s so the badge fades out
      setTimeout(() => {
        setCmdState((s) => (s[cmd] === 'queued' ? { ...s, [cmd]: 'idle' } : s))
      }, 4_000)
    }
  }

  // Build the props for each button (DRY)
  function btnProps(cmd: CommandName, label: string) {
    // Go Home is ALWAYS clickable (recovery) — except during a
    // Supabase insert in flight or when Supabase isn't configured.
    const blocked = !commandable
    const busy = busyCmd === cmd
    const state = cmdState[cmd]
    const disabled = blocked || busy
    const stateLabel =
      busy ? '…' :
      state === 'queued' ? 'Queued' :
      state === 'executed' ? 'Done' :
      state === 'error' ? '!' :
      label
    return {
      disabled,
      busy,
      state,
      stateLabel,
      title: blocked
        ? 'This screen is offline, so the command would not reach it'
        : `Send a '${cmd}' command to ${display.name} (inserted into display_commands)`,
    }
  }

  return (
    <article className="nu-card p-6 flex flex-col gap-5">
      {/* Phase 4.5: red alert banner if security_status === 'critical' */}
      {live && <SecurityAlert display={display} />}

      {/* Header: name + status + open-in-new-tab */}
      <header className="flex items-start gap-4">
        <div className="w-10 h-10 rounded-glass bg-nu-blue/15 border border-nu-blue/30 flex items-center justify-center text-nu-sky shrink-0">
          <IconDisplay size={20} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-3 flex-wrap">
            <h3 className="font-serif text-[22px] text-nu-wisp leading-none truncate">
              {display.name}
            </h3>
            <StatusBadge status={live ? 'online' : 'offline'} />
            {live && <SecurityBadge status={display.security_status} />}
          </div>
          {display.orientation && (
            <div className="mt-1 text-[12px] text-nu-skylight">
              {display.orientation}
            </div>
          )}
          {fromComputer && !fromTestLink && (
            <div className="mt-1 text-[11px] text-nu-sky">
              The last signal looks like it came from a computer ({deviceSummary(display.device_info)}), not from the screen on campus.
            </div>
          )}
          {testReason && (
            <div className="mt-1 text-[11px] text-nu-sky">
              {testTabMessage(display, testReason)}
            </div>
          )}
          {live && display.security_message && display.security_status !== 'secure' && (
            <div className={[
              'mt-1 text-[11px]',
              display.security_status === 'critical' ? 'text-nu-amber' : 'text-nu-sky',
            ].join(' ')}>
              {display.security_message}
            </div>
          )}
        </div>
        <a
          href={display.public_url || display.approved_url || '#'}
          target="_blank"
          rel="noreferrer noopener"
          aria-label={`Open ${display.name} in a new tab`}
          className="text-nu-skylight hover:text-nu-tour transition-colors shrink-0"
        >
          <IconExternal size={16} />
        </a>
      </header>

      {/* 1) Screenshot panel (Phase 3C: real image with loading/error states) */}
      <ScreenshotPanel display={display} live={live} />

      {/* 2) Current page / current URL (Phase 3B) */}
      <div className="grid grid-cols-1 gap-1 text-[12px]">
        <div className="flex items-center gap-2">
          <span className="nu-eyebrow text-[10px] w-20 shrink-0">Page</span>
          <code className="font-mono text-nu-sky truncate">
            {display.current_page ?? '—'}
          </code>
        </div>
        <div className="flex items-center gap-2 min-w-0">
          <span className="nu-eyebrow text-[10px] w-20 shrink-0">URL</span>
          <code className="font-mono text-nu-sky/80 truncate text-[11px]">
            {display.current_url ?? display.public_url ?? '—'}
          </code>
        </div>
      </div>

      {/* 3) Health grid (Phase 3D) — heartbeat, last touch, response, software */}
      <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[12px]">
        <Meta icon={<IconMapPin size={12} />} label="Location" value={display.location} />
        <Meta
          icon={<IconClock size={12} />}
          label="Response"
          value={display.response_time !== null ? `${display.response_time} ms` : '—'}
        />
        <Meta
          icon={<IconClock size={12} />}
          label="Last heartbeat"
          value={timeAgo(display.last_seen)}
          accent={live ? 'leaf' : 'amber'}
        />
        <Meta
          icon={<IconClock size={12} />}
          label="Last touch"
          value={timeAgo(display.last_touch)}
        />
        <Meta
          icon={<IconBolt size={12} />}
          label="Software"
          value={display.software_version ?? '—'}
        />
        <Meta
          icon={<IconClock size={12} />}
          label="Updated"
          value={timeAgo(display.updated_at)}
        />
        <div className="col-span-2">
          <Meta
            icon={<IconDisplay size={12} />}
            label="Device"
            value={deviceSummary(display.device_info)}
          />
        </div>
      </dl>

      {/* Phase 4.5: approved URL bar (subtle, shows what's allowed) */}
      {display.approved_url && (
        <div className="text-[11px] text-nu-skylight/70 flex items-center gap-2 min-w-0">
          <span className="nu-eyebrow text-[10px] w-20 shrink-0">Approved</span>
          <code className="font-mono text-nu-sky/70 truncate text-[11px]" title={display.approved_url}>
            {display.approved_url}
          </code>
        </div>
      )}

      {/* 4) Optional notes */}
      {display.notes && (
        <div className="text-[12px] text-nu-skylight/80 italic border-l-2 border-nu-tour/40 pl-3">
          {display.notes}
        </div>
      )}

      {/* 4b) Overlay mode indicators — show current blackout / emergency state */}
      {(blackoutActive || emergencyActive) && (
        <div className="flex items-center gap-2 flex-wrap">
          {blackoutActive && (
            <span className="nu-pill text-[10px] py-1 px-3 border-nu-tour/60 bg-nu-tour/15 text-nu-tour border">
              <IconBlock size={11} />
              <span>Blackout active</span>
            </span>
          )}
          {emergencyActive && (
            <span className="nu-pill text-[10px] py-1 px-3 border-nu-amber/60 bg-nu-amber/15 text-nu-amber border">
              <IconAlert size={11} />
              <span>Emergency active</span>
            </span>
          )}
          <span className="text-[10px] text-nu-skylight/70 ml-auto">
            Click <strong className="text-nu-tour">Go Home</strong> to recover
          </span>
        </div>
      )}

      <CommandStatus display={display} commands={commands} />

      {supabaseReady && !commandable && (
        <div className="text-[12px] text-nu-amber border-l-2 border-nu-amber/50 pl-3">
          {fromTestLink || fromComputer
            ? 'Only a test tab or a computer has reported recently. The screen on campus is not connected, so commands cannot reach it.'
            : `This screen is offline (last signal ${timeAgo(display.last_seen)}). Commands can't reach it. Reload the monitor on site to reconnect it.`}
        </div>
      )}

      <div className="text-[10px] font-bold tracking-[0.22em] uppercase text-nu-tour">
        Protect this screen
      </div>
      <div className="grid grid-cols-2 gap-2">
        {(() => {
          const b = btnProps('blackout', blackoutActive ? 'End Blackout' : 'Blackout')
          return (
            <Button
              variant={blackoutActive ? 'secondary' : 'danger'}
              size="sm"
              icon={blackoutActive ? <IconCheck /> : <IconBlock />}
              onClick={() => onCommand(blackoutActive ? 'clear_blackout' : 'blackout', blackoutActive ? 'End Blackout' : 'Blackout')}
              disabled={b.disabled}
              title={blackoutActive
                ? 'End the blackout overlay (display client clears local state + key)'
                : 'Activate the blackout overlay (display client shows fullscreen #000)'}
              className={b.state === 'queued' || b.state === 'executed' ? 'ring-1 ring-nu-tour/50' : ''}
            >
              {b.stateLabel}
            </Button>
          )
        })()}
        {(() => {
          const e = btnProps('emergency_message', emergencyActive ? 'End Emergency' : 'Emergency')
          return (
            <Button
              variant={emergencyActive ? 'secondary' : 'primary'}
              size="sm"
              icon={emergencyActive ? <IconCheck /> : <IconAlert />}
              onClick={() => onCommand(emergencyActive ? 'clear_emergency' : 'emergency_message', emergencyActive ? 'End Emergency' : 'Emergency')}
              disabled={e.disabled}
              title={emergencyActive
                ? 'End the emergency overlay (display client clears local state + key)'
                : 'Activate the emergency overlay (display client shows fullscreen red)'}
              className={e.state === 'queued' || e.state === 'executed' ? 'ring-1 ring-nu-tour/50' : ''}
            >
              {e.stateLabel}
            </Button>
          )
        })()}
      </div>

      <div className="text-[10px] font-bold tracking-[0.22em] uppercase text-nu-skylight/70">
        Recover
      </div>
      <div className="grid grid-cols-2 gap-2">
        {(() => {
          const r = btnProps('reload', 'Reload')
          return (
            <Button
              variant="secondary"
              size="sm"
              icon={<IconRefresh />}
              onClick={() => onCommand('reload', 'Reload')}
              disabled={r.disabled}
              title={r.title}
            >
              {r.stateLabel}
            </Button>
          )
        })()}
        {(() => {
          const g = btnProps('go_home', 'Go Home')
          return (
            <Button
              variant="secondary"
              size="sm"
              icon={<IconHome />}
              onClick={() => onCommand('go_home', 'Go Home')}
              disabled={g.disabled}
              title="Clear overlays and return this screen to home"
            >
              {g.stateLabel}
            </Button>
          )
        })()}
      </div>

      {/* Last error feedback (DEV-friendly surface for any send failure) */}
      {cmdError && (
        <div className="text-[11px] text-nu-amber border-l-2 border-nu-amber/50 pl-3">
          {cmdError}
        </div>
      )}

    </article>
  )
}

/* --------- Sub-components --------- */

function Meta({
  icon, label, value, accent,
}: {
  icon: ReactNode
  label: string
  value: string
  accent?: 'leaf' | 'amber' | 'sky'
}) {
  const color = accent === 'leaf' ? 'text-nu-leaf'
    : accent === 'amber' ? 'text-nu-amber'
    : accent === 'sky' ? 'text-nu-sky'
    : 'text-nu-wisp'
  return (
    <div className="flex items-center gap-2 min-w-0">
      <span className="text-nu-skylight/60 shrink-0">{icon}</span>
      <span className="text-nu-skylight/70 text-[10px] uppercase tracking-wider font-bold whitespace-nowrap">
        {label}
      </span>
      <span className={['font-mono text-[11px] ml-auto truncate', color].join(' ')} title={value}>
        {value}
      </span>
    </div>
  )
}