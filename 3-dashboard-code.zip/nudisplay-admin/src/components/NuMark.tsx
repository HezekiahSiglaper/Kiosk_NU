/**
 * Small NU-style monogram used in the admin header.
 * Echoes the gold-tour gradient used across the display apps.
 */
export function NuMark({ size = 28 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="nuGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#fbd945" />
          <stop offset="100%" stopColor="#ffbc2d" />
        </linearGradient>
      </defs>
      <rect
        x="2"
        y="2"
        width="60"
        height="60"
        rx="14"
        fill="#00263d"
        stroke="url(#nuGrad)"
        strokeWidth="2"
      />
      <text
        x="32"
        y="42"
        textAnchor="middle"
        fontFamily='"Times New Roman", Times, serif'
        fontSize="32"
        fontWeight="700"
        fill="url(#nuGrad)"
      >
        N
      </text>
    </svg>
  )
}
