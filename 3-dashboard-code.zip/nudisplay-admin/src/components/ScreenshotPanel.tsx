import { useState } from 'react'
import type { Display } from '../types/display'
import { USE_NEON } from '../services/backend'
import { IconImage, IconExternal } from './icons'

/**
 * Shows what is on the physical kiosk: the JPEG the display client
 * uploads to Storage (display-screenshots/{id}/latest.jpg).
 * An iframe of the public URL is a second copy of the website, not
 * the TV, so it is only a fallback when no snapshot exists.
 */

export function ScreenshotPanel({ display, live }: { display: Display; live: boolean }) {
  const [open, setOpen] = useState(false)
  const shot = screenshotSrc(display)
  const age = timeAgo(display.screenshot_updated_at)
  const online = live
  // Only call a photo "old" once it is more than a day old.
  const stale = display.screenshot_updated_at
    ? Date.now() - Date.parse(display.screenshot_updated_at) > 86_400_000
    : true

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between text-[11px] text-nu-skylight/70 px-1">
        <span className="nu-eyebrow text-[10px]">Physical screen</span>
        {display.screenshot_updated_at && (
          <span className="font-mono text-[10px] text-nu-skylight/50">Updated {age}</span>
        )}
      </div>

      <div
        className="relative mx-auto w-full overflow-hidden rounded-glass border border-white/10 bg-nu-navy/40"
        style={{ aspectRatio: '9 / 16', maxWidth: '280px', maxHeight: '500px' }}
      >
        {shot ? (
          <button
            type="button"
            className="absolute inset-0 block w-full h-full"
            onClick={() => setOpen(true)}
            title="Enlarge snapshot"
          >
            <img
              src={shot}
              alt={`${display.name} physical screen`}
              className={[
                'absolute inset-0 w-full h-full object-cover object-top bg-nu-midnight',
                stale ? 'opacity-40 grayscale' : '',
              ].join(' ')}
            />
            {stale ? (
              <span className="absolute top-2 right-2 rounded-full bg-nu-midnight/85 border border-nu-amber/40 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-nu-amber">
                Old photo · {age}
              </span>
            ) : online ? (
              <span className="absolute top-2 right-2 flex items-center gap-1.5 rounded-full bg-nu-midnight/85 border border-nu-leaf/40 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-nu-leaf">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-nu-leaf animate-pulse" />
                On glass
              </span>
            ) : (
              <span className="absolute top-2 right-2 rounded-full bg-nu-midnight/85 border border-white/20 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-nu-skylight">
                Last photo · {age}
              </span>
            )}
          </button>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center p-5 text-center">
            <div>
              <IconImage size={28} className="text-nu-skylight/30 mx-auto" />
              <div className="nu-eyebrow mt-2 text-[10px] text-nu-skylight/60">
                {online ? 'Waiting for snapshot' : 'Display offline'}
              </div>
              <p className="mt-1 text-[11px] text-nu-skylight/50 max-w-[200px] mx-auto">
                {online
                  ? 'The kiosk uploads a photo of the TV about every 20 seconds.'
                  : 'Snapshot resumes when the kiosk reports online.'}
              </p>
            </div>
          </div>
        )}

        {previewHref(display) && (
          <a
            href={previewHref(display)!}
            target="_blank"
            rel="noreferrer noopener"
            className="absolute bottom-2 left-2 flex items-center gap-1 rounded-full bg-nu-midnight/80 border border-white/15 px-2 py-0.5 text-[10px] text-nu-skylight hover:text-nu-tour"
          >
            <IconExternal size={10} /> Open site
          </a>
        )}
      </div>

      {open && shot && (
        <div
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-6"
          onClick={() => setOpen(false)}
          role="dialog"
          aria-label="Enlarged screen snapshot"
        >
          <img
            src={shot}
            alt={`${display.name} enlarged`}
            className="max-h-[90vh] max-w-[90vw] object-contain rounded-lg border border-white/20"
          />
        </div>
      )}
    </div>
  )
}

/**
 * Only images from our own screenshot bucket are shown. The column is
 * writable by the public key, so any other URL is ignored rather than
 * rendered in the dashboard.
 */
const SCREENSHOT_PREFIX = `${String(import.meta.env.VITE_SUPABASE_URL || '').replace(/\/$/, '')}/storage/v1/object/public/display-screenshots/`

/**
 * Neon mode: only the display API writes screenshot_url, always to the
 * project's Neon Object Storage (api/_lib/neon.js, putScreenshot).
 */
const NEON_SCREENSHOT_URL = /^https:\/\/[a-z0-9.-]+\.neon\.tech\/display-screenshots\//

function isOurScreenshot(url: string): boolean {
  return USE_NEON ? NEON_SCREENSHOT_URL.test(url) : url.startsWith(SCREENSHOT_PREFIX)
}

function screenshotSrc(display: Display): string | null {
  const url = display.screenshot_url
  if (!url || !isOurScreenshot(url)) return null
  const t = display.screenshot_updated_at
    ? Date.parse(display.screenshot_updated_at)
    : Date.now()
  const sep = url.includes('?') ? '&' : '?'
  return `${url}${sep}t=${t}`
}

function previewHref(display: Display): string | null {
  if (display.public_url) return display.public_url
  if (display.approved_url) return display.approved_url
  return null
}

function timeAgo(iso: string | null): string {
  if (!iso) return '—'
  const diff = Date.now() - new Date(iso).getTime()
  if (diff < 15_000) return 'just now'
  if (diff < 60_000) return `${Math.floor(diff / 1000)}s ago`
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`
  if (diff < 172_800_000) return `${Math.floor(diff / 3_600_000)}h ago`
  return `${Math.floor(diff / 86_400_000)} days ago`
}
